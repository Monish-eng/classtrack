-- ══════════════════════════════════════════════════════
--  ClassTrack  —  Supabase Database Setup
--  Run this entire script in your Supabase SQL Editor
-- ══════════════════════════════════════════════════════

-- 1. STUDENTS TABLE
create table if not exists ct_students (
  id          text not null,
  user_id     text not null,
  name        text not null,
  roll        text,
  dept        text,
  created_at  timestamptz default now(),
  primary key (id, user_id)
);

-- 2. TIMETABLE TABLE
create table if not exists ct_timetable (
  user_id     text not null,
  day         text not null,
  period      text not null,
  subject     text,
  faculty     text,
  "startTime" text,
  "endTime"   text,
  primary key (user_id, day, period)
);

-- 3. ATTENDANCE TABLE
create table if not exists ct_attendance (
  id          bigserial primary key,
  user_id     text not null,
  date        text not null,
  period      text not null,
  day         text,
  subject     text,
  topic       text,
  "startTime" text,
  "endTime"   text,
  attendance  jsonb,
  created_at  timestamptz default now(),
  unique (user_id, date, period)
);

-- 4. ROW LEVEL SECURITY  (each teacher sees only their own data)
alter table ct_students   enable row level security;
alter table ct_timetable  enable row level security;
alter table ct_attendance enable row level security;

-- Students policies
create policy "students_select" on ct_students for select using (user_id = auth.uid()::text);
create policy "students_insert" on ct_students for insert with check (user_id = auth.uid()::text);
create policy "students_delete" on ct_students for delete using (user_id = auth.uid()::text);

-- Timetable policies
create policy "tt_select" on ct_timetable for select using (user_id = auth.uid()::text);
create policy "tt_insert" on ct_timetable for insert with check (user_id = auth.uid()::text);
create policy "tt_delete" on ct_timetable for delete using (user_id = auth.uid()::text);

-- Attendance policies
create policy "att_select" on ct_attendance for select using (user_id = auth.uid()::text);
create policy "att_insert" on ct_attendance for insert with check (user_id = auth.uid()::text);
create policy "att_delete" on ct_attendance for delete using (user_id = auth.uid()::text);

-- 5. INDEXES for fast queries
create index if not exists idx_students_user   on ct_students(user_id);
create index if not exists idx_timetable_user  on ct_timetable(user_id);
create index if not exists idx_attendance_user on ct_attendance(user_id);
create index if not exists idx_attendance_date on ct_attendance(user_id, date);

-- Done! ✓
-- Now go to Project Settings → API and copy:
--   • Project URL  →  paste as SB_URL  in ClassTrack.jsx
--   • anon key     →  paste as SB_KEY  in ClassTrack.jsx
